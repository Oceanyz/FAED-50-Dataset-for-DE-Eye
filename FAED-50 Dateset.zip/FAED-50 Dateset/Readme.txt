The FAED-50 Dataset
-------------------
link:

Files
-----
FAED-50 Dataset.zip

Description
-----------
The FAED-50 Dataset has been built and published to give all researchers
working the area of eye localization the possibility to compare the quality of their eye localization algorithms with others. The images are 
captured under the near-infrared environment with a low-cost camera.

The dataset consists of 2498 gray level eye patch images with a resolution of 201*101 pixels which are cropped from the original nearly frontally-viewed face iamges. These images are from 50 different test persons.The eyes are finely annotated by hand-drawing the contour of the upper eyelid, the lower eyelid, the left limbus, the right limbus, and the pupil.The original annotation data are saved and shared in this set.

Image File Format
-----------------
The dataset consists of two sub-folders,"Images" and "Annotations". The images are in the folder of "Images".There are 50 subfolders in the name of "Subjectxx" in "Images",one folder for each person. The images are stored in each folder in the name of "Subjectxx #xxxx.jpg".

Annotation File Format
----------------------
The annotation information are in the folder of "Annotations".There are 50 subfolders in the name of "Subjectxx" in "Annotations",one folder for each person.The annotations are stored in each folder in the name of "Subjectxx #xxxx.mat". The data are arranged in Struct format.
Data.Name -> The image name;
Data.upper_eyelid -> The labelled contour points of the upper eyelid; Data.lower_eyelid -> The labelled contour points of the lower eyelid; Data.limbus_left -> The labelled contour points of the left limbus; Data.limbus_right -> The labelled contour points of the right limbus; Data.pupil -> The labelled contour points of the pupil.

Fore more information about the FAED-50 Dataset, sample pictures and the annotation method, please visit


-----------------------------------------
11/10/2020 